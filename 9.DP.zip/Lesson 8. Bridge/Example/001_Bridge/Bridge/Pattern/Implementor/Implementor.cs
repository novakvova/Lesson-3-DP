using System;

namespace Bridge
{
    abstract class Implementor
    {
        public abstract void OperationImp();
    }
}

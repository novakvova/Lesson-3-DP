﻿using System;


namespace ServiceLocator_1
{
    class ServiceB : IServiceB
    {

    }
}

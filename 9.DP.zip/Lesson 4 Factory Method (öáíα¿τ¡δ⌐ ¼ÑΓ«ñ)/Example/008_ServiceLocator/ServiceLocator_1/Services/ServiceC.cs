﻿using System;


namespace ServiceLocator_1
{
    class ServiceC : IServiceC
    {

    }
}

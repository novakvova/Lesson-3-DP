﻿
namespace FM_With_Argument
{
    enum ProductType
    {
        MINE, YOURS, THEIRS
    }
}

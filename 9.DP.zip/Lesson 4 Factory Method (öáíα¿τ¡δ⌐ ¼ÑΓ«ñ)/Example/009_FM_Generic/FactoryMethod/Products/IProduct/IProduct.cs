﻿using System;

namespace FactoryMethod
{
    interface IProduct
    {
    }
}

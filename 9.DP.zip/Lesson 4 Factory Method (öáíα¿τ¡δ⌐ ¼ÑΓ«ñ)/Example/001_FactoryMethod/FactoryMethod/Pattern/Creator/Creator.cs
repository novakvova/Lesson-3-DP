using System;

namespace FactoryMethod
{   
    abstract class Creator
    {
        Product product;

        public abstract Product FactoryMethod();

        public void AnOperation()
        {
            Console.WriteLine("Create product Concreate Creator");
            product = FactoryMethod();
        }
    }
}

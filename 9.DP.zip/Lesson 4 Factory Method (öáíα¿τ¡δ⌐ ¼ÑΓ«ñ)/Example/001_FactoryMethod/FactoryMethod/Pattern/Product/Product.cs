using System;

namespace FactoryMethod
{
    abstract class Product
    {
    }
}

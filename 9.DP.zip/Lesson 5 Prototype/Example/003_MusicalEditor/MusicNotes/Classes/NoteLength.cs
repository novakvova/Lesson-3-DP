﻿
namespace MusicNotes
{
    public enum NoteLength
    {
        HalfNote,
        WholeNote,
        QuarterNote,
        Eighth,
        Sixteenth
    }
}

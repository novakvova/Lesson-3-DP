﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPrototype
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****Граем с IClonable****\n");
            Console.WriteLine("Клонируем p3, новый сохраняем в p4");
            Point p3 = new Point(100, 100, "Jane");
            Point p4 = (Point)p3.Clone();
            Console.WriteLine("До модификации: ");
            Console.WriteLine("p3: {0}", p3);
            Console.WriteLine("p4: {0}", p4);
            p4.desc.petName = "Mister X";
            p4.x = 4;
            Console.WriteLine("Изменение p4.desc.petName и p4.x: ");
            Console.WriteLine("После модификации: ");
            Console.WriteLine("p3: {0}", p3);
            Console.WriteLine("p4: {0}", p4);

        }
    }
}

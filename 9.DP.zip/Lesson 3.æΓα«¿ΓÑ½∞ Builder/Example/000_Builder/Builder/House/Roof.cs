﻿using System;

namespace Builder
{
    class Roof
    {
        public Roof()
        {
            Console.WriteLine("Крыша построена");
        }
    }
}

﻿using System;

namespace Builder
{
    class Storey
    {
        public Storey()
        {
            Console.WriteLine("Этаж построен");
        }
    }
}

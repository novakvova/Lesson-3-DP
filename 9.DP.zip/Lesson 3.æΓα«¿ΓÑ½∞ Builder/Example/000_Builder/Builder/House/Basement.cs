﻿
using System;

namespace Builder
{
    class Basement
    {
        public Basement()
        {
            Console.WriteLine("Подвал построен");
        }
    }
}

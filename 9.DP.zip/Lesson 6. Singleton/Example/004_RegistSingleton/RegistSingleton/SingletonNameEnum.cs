﻿
namespace RegistSingleton
{
    public enum SingletonName
    {
        Simple, 
        Big, 
        Small
    }
}

﻿using System;

namespace Adapter
{
    interface ITarget
    {
        void Request();
    }
}

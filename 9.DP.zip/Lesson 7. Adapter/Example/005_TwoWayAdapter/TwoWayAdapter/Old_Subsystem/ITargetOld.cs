﻿
namespace TwoWayAdapter
{
    interface ITargetOld
    {
        void MethodOld();
    }
}
